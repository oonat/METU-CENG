/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

unsigned addval_275(unsigned x)
{
    return x + 3286206792U;
}

unsigned addval_245(unsigned x)
{
    return x + 3284240712U;
}

unsigned addval_477(unsigned x)
{
    return x + 2428930376U;
}

unsigned getval_110()
{
    return 2428602696U;
}

unsigned addval_343(unsigned x)
{
    return x + 3284699464U;
}

unsigned getval_247()
{
    return 3284568392U;
}

void setval_267(unsigned *p)
{
    *p = 2428645704U;
}

unsigned getval_425()
{
    return 3284699464U;
}

void setval_479(unsigned *p)
{
    *p = 4085893296U;
}

void setval_164(unsigned *p)
{
    *p = 2496170312U;
}

void setval_253(unsigned *p)
{
    *p = 3750316287U;
}

unsigned getval_402()
{
    return 2455337399U;
}

unsigned addval_169(unsigned x)
{
    return x + 3284699480U;
}

unsigned getval_155()
{
    return 3269429576U;
}

void setval_333(unsigned *p)
{
    *p = 2464123208U;
}

unsigned getval_434()
{
    return 2425393241U;
}

void setval_431(unsigned *p)
{
    *p = 3287517512U;
}

void setval_428(unsigned *p)
{
    *p = 2428645696U;
}

unsigned getval_463()
{
    return 2495754568U;
}

void setval_252(unsigned *p)
{
    *p = 2428645704U;
}

void setval_480(unsigned *p)
{
    *p = 2448656712U;
}

void setval_348(unsigned *p)
{
    *p = 2431879496U;
}

unsigned getval_349()
{
    return 3284240456U;
}

unsigned addval_172(unsigned x)
{
    return x + 2462484808U;
}

unsigned addval_188(unsigned x)
{
    return x + 2425393241U;
}

void setval_182(unsigned *p)
{
    *p = 3284569416U;
}

unsigned addval_375(unsigned x)
{
    return x + 2425375210U;
}

void setval_393(unsigned *p)
{
    *p = 3284241224U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
